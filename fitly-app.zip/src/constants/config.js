export default {
  API_ROOT_URL: "http://ec2-18-219-119-244.us-east-2.compute.amazonaws.com:3000/api",
}
