import TheContent from "../TheContent"
import TheFooter from "../TheFooter"
import TheHeader from "../TheHeader"
import TheLayout from "./TheLayout"

export { TheContent, TheFooter, TheHeader, TheLayout }
