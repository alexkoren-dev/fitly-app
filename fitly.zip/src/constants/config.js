export default {
  API_ROOT_URL: "http://ec2-18-219-119-244.us-east-2.compute.amazonaws.com:3000/api",
  STRIPE_API_KEY:
    "pk_test_51H74lwGdCZ2WGYzLPyo7V9HZ4qt69iaxldqggxft8sJYOk5iZasvkqT2faGkjuDPC6OzFO71iKv1pIhWburBxE1j00yisbTeAS",
}
