import * as StripeActions from "./actions"

export default {
	... StripeActions
}