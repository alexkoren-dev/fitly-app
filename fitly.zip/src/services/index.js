import configureStore from "./store"

export { configureStore }
