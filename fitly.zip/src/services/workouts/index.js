import * as WorkoutActions from "./actions"

export default {
	...WorkoutActions
}