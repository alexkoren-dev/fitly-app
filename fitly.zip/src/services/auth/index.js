import * as AuthActions from "./actions"

export default {
	...AuthActions
}