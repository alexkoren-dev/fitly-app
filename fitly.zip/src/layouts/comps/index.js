import TheContent from "./TheContent"
import TheFooter from "./TheFooter"
import TheHeader from "./TheHeader"

export { TheContent, TheFooter, TheHeader }
