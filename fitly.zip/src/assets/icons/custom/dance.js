export const cuDance = [
  "40 60",
  `
    <g id="Group_27" data-name="Group 27" transform="translate(-492.764 -489)">
        <ellipse id="Ellipse_16" data-name="Ellipse 16" cx="5.526" cy="5.526" rx="5.526" ry="5.526" transform="translate(507.917 489)" fill="#5b5b5b"/>
        <rect id="Rectangle_33" data-name="Rectangle 33" width="5.925" height="22.145" rx="2.963" transform="translate(515.981 499.803) rotate(88)" fill="#5b5b5b"/>
        <path id="Rectangle_36" data-name="Rectangle 36" d="M0,0H10.534a0,0,0,0,1,0,0V12.928a5.267,5.267,0,0,1-5.267,5.267h0A5.267,5.267,0,0,1,0,12.928V0A0,0,0,0,1,0,0Z" transform="matrix(0.995, 0.105, -0.105, 0.995, 504.866, 504.35)" fill="#5b5b5b"/>
        <rect id="Rectangle_37" data-name="Rectangle 37" width="5.925" height="15.92" rx="2.963" transform="translate(494.151 501.028) rotate(5)" fill="#5b5b5b"/>
        <rect id="Rectangle_38" data-name="Rectangle 38" width="6.404" height="17.357" rx="3.202" transform="translate(505.407 518.14) rotate(-3)" fill="#5b5b5b"/>
        <rect id="Rectangle_39" data-name="Rectangle 39" width="5.925" height="19.272" rx="2.963" transform="matrix(0.883, 0.469, -0.469, 0.883, 508.223, 528.557)" fill="#5b5b5b"/>
        <rect id="Rectangle_40" data-name="Rectangle 40" width="6.404" height="16.878" rx="3.202" transform="translate(509.85 503.106) rotate(-45)" fill="#5b5b5b"/>
        <rect id="Rectangle_41" data-name="Rectangle 41" width="6.404" height="16.878" rx="3.202" transform="translate(527.175 497.072) rotate(33)" fill="#5b5b5b"/>
        <rect id="Rectangle_42" data-name="Rectangle 42" width="5.925" height="17.357" rx="2.963" transform="translate(508.987 523.01) rotate(-89)" fill="#5b5b5b"/>
        <rect id="Rectangle_43" data-name="Rectangle 43" width="5.925" height="19.272" rx="2.963" transform="translate(522.499 516.484) rotate(22)" fill="#5b5b5b"/>
    </g>
`,
]
