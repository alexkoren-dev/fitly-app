export const cuUserFill = [
  "24 24",
  `
	<g id="Group_33" data-name="Group 33" transform="translate(-1988 -42)">
		<circle id="Ellipse_21" data-name="Ellipse 21" cx="7.5" cy="7.5" r="7.5" transform="translate(1993 42)" fill="#fff"/>
		<path id="Rectangle_55" data-name="Rectangle 55" d="M9.706,0h4.588A9.706,9.706,0,0,1,24,9.706v0A1.294,1.294,0,0,1,22.706,11H1.294A1.294,1.294,0,0,1,0,9.706v0A9.706,9.706,0,0,1,9.706,0Z" transform="translate(1988 55)" fill="#fff"/>
	</g>
`,
]
