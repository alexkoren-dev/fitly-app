export const cuUserOutline = [
  "24 25",
  `
	<g id="Group_31" data-name="Group 31" transform="translate(-244.585 -795)">
		<g id="Path_35" data-name="Path 35" transform="translate(244.585 806)" fill="none">
			<path d="M12,0A12,12,0,0,1,24,12v.8A1.2,1.2,0,0,1,22.8,14H1.2A1.2,1.2,0,0,1,0,12.8V12A12,12,0,0,1,12,0Z" stroke="none"/>
			<path d="M 12 1.5 C 6.21027946472168 1.5 1.5 6.210279941558838 1.5 12 L 1.5 12.5 L 22.5 12.5 L 22.5 12 C 22.5 6.210279941558838 17.78972053527832 1.5 12 1.5 M 12 0 C 18.62742042541504 0 24 5.372579574584961 24 12 L 24 12.80000019073486 C 24 13.46273994445801 23.46273994445801 14 22.79999923706055 14 L 1.200000762939453 14 C 0.5372600555419922 14 0 13.46273994445801 0 12.80000019073486 L 0 12 C 0 5.372579574584961 5.372579574584961 0 12 0 Z" stroke="none" fill="#5063ee"/>
		</g>
		<g id="Ellipse_14" data-name="Ellipse 14" transform="translate(249.573 795)" fill="none" stroke="#4e65ef" stroke-width="1.5">
			<circle cx="7" cy="7" r="7" stroke="none"/>
			<circle cx="7" cy="7" r="6.25" fill="none"/>
		</g>
	</g>
`,
]
