export const cuClock = [
  "23.5 23.5",
  `
	<g id="Ellipse_2" data-name="Ellipse 2" fill="none" stroke="#5063ee" stroke-width="1.5">
		<circle cx="11.75" cy="11.75" r="11.75" stroke="none"/>
		<circle cx="11.75" cy="11.75" r="11" fill="none"/>
	</g>
	<line id="Line_3" data-name="Line 3" y2="8.135" transform="translate(11.298 4.971)" fill="none" stroke="#5063ee" stroke-linecap="round" stroke-width="1.5"/>
	<line id="Line_4" data-name="Line 4" x1="6.327" y2="3.615" transform="translate(11.298 9.49)" fill="none" stroke="#5063ee" stroke-linecap="round" stroke-width="1.5"/>
`,
]
