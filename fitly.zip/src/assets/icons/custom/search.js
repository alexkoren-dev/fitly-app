export const cuSearch = [
  "33 33",
  `
	<g id="Group_32" data-name="Group 32" transform="translate(-1483 -43)">
		<g id="Ellipse_22" data-name="Ellipse 22" transform="translate(1483 43)" fill="none" stroke="#707070" stroke-width="5">
			<ellipse cx="13" cy="12.5" rx="13" ry="12.5" stroke="none"/>
			<ellipse cx="13" cy="12.5" rx="10.5" ry="10" fill="none"/>
		</g>
		<line id="Line_6" data-name="Line 6" x2="8" y2="7" transform="translate(1503.5 62.5)" fill="none" stroke="#707070" stroke-linecap="round" stroke-width="5"/>
	</g>
`,
]
